// Configure Monaco Editor loader
require.config({ paths: { 'vs': 'https://unpkg.com/monaco-editor/min/vs' } });
require(['vs/editor/editor.main'], function() {
    // Create editors with autocomplete and error checking
    const htmlEditor = monaco.editor.create(document.getElementById('htmlEditor'), {
        language: 'html',
        theme: 'vs-dark',
        automaticLayout: true,
        wordBasedSuggestions: true,
        suggest: {
            filterGraceful: true
        }
    });
    const cssEditor = monaco.editor.create(document.getElementById('cssEditor'), {
        language: 'css',
        theme: 'vs-dark',
        automaticLayout: true,
        wordBasedSuggestions: true,
        suggest: {
            filterGraceful: true
        }
    });
    const jsEditor = monaco.editor.create(document.getElementById('jsEditor'), {
        language: 'javascript',
        theme: 'vs-dark',
        automaticLayout: true,
        wordBasedSuggestions: true,
        suggest: {
            filterGraceful: true
        }
    });

    function updatePreview() {
        const html = htmlEditor.getValue();
        const css = `<style>${cssEditor.getValue()}</style>`;
        const js = `<script>${jsEditor.getValue()}<\/script>`;
        const previewContent = `${html}\n${css}\n${js}`;
        const previewDocument = document.getElementById('preview').contentDocument || document.getElementById('preview').contentWindow.document;
        previewDocument.open();
        previewDocument.write(previewContent);
        previewDocument.close();
    }

    // Add listeners for editor changes
    htmlEditor.onDidChangeModelContent(updatePreview);
    cssEditor.onDidChangeModelContent(updatePreview);
    jsEditor.onDidChangeModelContent(updatePreview);

    // Initialize preview
    updatePreview();
});
